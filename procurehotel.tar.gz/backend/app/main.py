"""
ProcureHotel — FastAPI app entrypoint.
"""

from __future__ import annotations

from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api.v1 import api_router
from app.core.config import settings
from app.core.logging import setup_logging


@asynccontextmanager
async def lifespan(_: FastAPI):
    setup_logging()
    yield


app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description=(
        "Sistema Inteligente de Compras para Hotelaria — API REST. "
        "Documentação interativa disponível em /docs (Swagger) e /redoc."
    ),
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.backend_cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health", tags=["health"])
async def health():
    return {"status": "ok", "app": settings.app_name, "version": settings.app_version}


@app.get("/", include_in_schema=False)
async def root():
    return JSONResponse(
        {
            "name": settings.app_name,
            "version": settings.app_version,
            "api": settings.api_v1_prefix,
            "docs": "/docs",
        }
    )


app.include_router(api_router, prefix=settings.api_v1_prefix)
