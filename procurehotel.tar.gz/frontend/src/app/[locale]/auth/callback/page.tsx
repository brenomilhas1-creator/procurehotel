'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useLocale } from 'next-intl';
import { Loader2 } from 'lucide-react';
import { getSupabase } from '@/lib/supabase';
import { useAuthStore } from '@/stores/auth';
import { apiGet } from '@/lib/api';

export default function AuthCallback() {
  const router = useRouter();
  const locale = useLocale();
  const [status, setStatus] = useState<'working' | 'ok' | 'error'>('working');
  const [msg, setMsg] = useState('A finalizar sessão...');

  useEffect(() => {
    (async () => {
      const sb = getSupabase();
      if (!sb) { setStatus('error'); setMsg('Supabase não configurado'); return; }
      const { data, error } = await sb.auth.getSession();
      if (error) { setStatus('error'); setMsg(error.message); return; }
      if (!data.session) { setStatus('error'); setMsg('Sessão não encontrada'); return; }
      useAuthStore.setState({
        accessToken: data.session.access_token,
        refreshToken: data.session.refresh_token,
      });
      try {
        const me = await apiGet<any>('/auth/me');
        useAuthStore.getState().setUser(me);
      } catch { /* ignore */ }
      setStatus('ok');
      setMsg('Sessão ativa. A redirecionar...');
      setTimeout(() => router.push(`/${locale}/dashboard`), 400);
    })();
  }, [router, locale]);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center text-sm text-muted-foreground gap-2">
      {status === 'working' && <Loader2 className="h-6 w-6 animate-spin" />}
      <p>{msg}</p>
    </div>
  );
}
