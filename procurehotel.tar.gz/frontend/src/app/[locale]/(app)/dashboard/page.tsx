'use client';

import { useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';
import { ShoppingCart, Package, Truck, TrendingDown, Euro } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { apiGet } from '@/lib/api';
import { formatCurrency } from '@/lib/utils';

interface Kpi {
  monthly_spend: { month: string; total: number; orders: number }[];
  top_products: { product_id: string; name: string; quantity: number; total: number }[];
  top_suppliers: { supplier_id: string; name: string; orders: number; total: number }[];
  savings: { period_days: number; actual_spend: number; estimated_savings: number };
}

export default function DashboardPage() {
  const t = useTranslations('analytics');
  const [kpi, setKpi] = useState<Kpi | null>(null);

  useEffect(() => {
    apiGet<Kpi>('/analytics/summary').then(setKpi).catch(() => setKpi(null));
  }, []);

  const totalThisMonth = kpi?.monthly_spend.at(-1)?.total ?? 0;
  const ordersThisMonth = kpi?.monthly_spend.at(-1)?.orders ?? 0;
  const topSupplier = kpi?.top_suppliers[0];

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{t('title')}</h1>
        <p className="text-sm text-muted-foreground">Visão geral das compras e poupanças</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard icon={<Euro className="h-4 w-4" />} label="Gasto este mês" value={formatCurrency(totalThisMonth)} />
        <KpiCard icon={<ShoppingCart className="h-4 w-4" />} label="Pedidos este mês" value={String(ordersThisMonth)} />
        <KpiCard icon={<Truck className="h-4 w-4" />} label="Top fornecedor" value={topSupplier?.name ?? '—'} />
        <KpiCard icon={<TrendingDown className="h-4 w-4" />} label="Poupança (30d)" value={formatCurrency(kpi?.savings.actual_spend ?? 0)} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Package className="h-4 w-4" /> {t('topProducts')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {kpi?.top_products.length ? kpi.top_products.map((p) => (
                <li key={p.product_id} className="flex justify-between text-sm">
                  <span className="truncate">{p.name}</span>
                  <span className="text-muted-foreground">{formatCurrency(p.total)}</span>
                </li>
              )) : <li className="text-sm text-muted-foreground">Sem dados — faça uma importação de preços.</li>}
            </ul>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Truck className="h-4 w-4" /> {t('topSuppliers')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="space-y-2">
              {kpi?.top_suppliers.length ? kpi.top_suppliers.map((s) => (
                <li key={s.supplier_id} className="flex justify-between text-sm">
                  <span className="truncate">{s.name}</span>
                  <span className="text-muted-foreground">{formatCurrency(s.total)} ({s.orders} ped.)</span>
                </li>
              )) : <li className="text-sm text-muted-foreground">Sem dados — registe fornecedores e faça pedidos.</li>}
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function KpiCard({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <Card>
      <CardContent className="p-5">
        <div className="flex items-center gap-2 text-muted-foreground text-xs">
          {icon} {label}
        </div>
        <div className="mt-2 text-2xl font-semibold">{value}</div>
      </CardContent>
    </Card>
  );
}
