'use client';

import { useEffect, useRef, useState } from 'react';
import { useTranslations } from 'next-intl';
import { UploadCloud, Check, X, Loader2, FileText } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Table, THead, TBody, TR, TH, TD } from '@/components/ui/table';
import { apiGet, apiPost, apiUpload } from '@/lib/api';

interface ImportRow {
  id: string;
  original_filename: string;
  status: string;
  rows_total: number;
  rows_approved: number;
  rows_rejected: number;
  created_at: string;
}

interface NormalizedRow {
  row_index: number;
  raw_text: string;
  suggested_name: string | null;
  brand: string | null;
  quantity: number | null;
  unit: string | null;
  price: number | null;
  confidence: number;
  action: string;
}

export default function ImportsPage() {
  const t = useTranslations('imports');
  const tCommon = useTranslations('common');
  const [imports, setImports] = useState<ImportRow[]>([]);
  const [suppliers, setSuppliers] = useState<{ id: string; name: string }[]>([]);
  const [supplierId, setSupplierId] = useState<string>('');
  const [busy, setBusy] = useState(false);
  const [current, setCurrent] = useState<any | null>(null);
  const [decisions, setDecisions] = useState<Record<number, 'approve' | 'ignore'>>({});
  const fileRef = useRef<HTMLInputElement>(null);

  async function load() {
    const data = await apiGet<{ items: ImportRow[] }>('/imports?size=20');
    setImports(data.items);
  }
  async function loadSuppliers() {
    const data = await apiGet<{ items: any[] }>('/suppliers?size=100');
    setSuppliers(data.items.map((s) => ({ id: s.id, name: s.name })));
    if (data.items[0]) setSupplierId(data.items[0].id);
  }

  useEffect(() => { load(); loadSuppliers(); }, []);

  async function onUpload(file: File) {
    if (!supplierId) {
      alert('Selecione um fornecedor primeiro');
      return;
    }
    setBusy(true);
    try {
      const fd = new FormData();
      fd.append('file', file);
      fd.append('supplier_id', supplierId);
      const rec = await apiUpload('/imports', fd);
      setCurrent(rec);
    } catch (e: any) {
      alert(e?.message || 'Erro no upload');
    } finally {
      setBusy(false);
    }
  }

  async function onSubmitReview() {
    if (!current) return;
    setBusy(true);
    try {
      const payload = {
        decisions: Object.entries(decisions).map(([idx, action]) => ({
          row_index: Number(idx), action,
        })),
        default_supplier_id: current.supplier_id ?? supplierId,
      };
      const rec = await apiPost(`/imports/${current.id}/review`, payload);
      setCurrent(rec);
      setDecisions({});
      await load();
    } catch (e: any) {
      alert(e?.message || 'Erro');
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{t('title')}</h1>
        <p className="text-sm text-muted-foreground">PDF, Excel, Word, CSV e imagens. A IA extrai e normaliza as linhas.</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{t('upload')}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex flex-wrap items-center gap-2">
            <select
              value={supplierId}
              onChange={(e) => setSupplierId(e.target.value)}
              className="h-10 rounded-md border bg-background px-3 text-sm"
            >
              <option value="">— {t('supplier')} —</option>
              {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}
            </select>
            <input
              ref={fileRef}
              type="file"
              accept=".pdf,.xlsx,.xls,.csv,.docx,.doc,.png,.jpg,.jpeg"
              hidden
              onChange={(e) => e.target.files?.[0] && onUpload(e.target.files[0])}
            />
            <Button onClick={() => fileRef.current?.click()} disabled={busy}>
              {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <UploadCloud className="h-4 w-4" />}
              {t('upload')}
            </Button>
          </div>
        </CardContent>
      </Card>

      {current && current.normalized_rows?.length > 0 && (
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-4 w-4" /> {current.original_filename}
            </CardTitle>
            <Badge>{current.status}</Badge>
          </CardHeader>
          <CardContent>
            <Table>
              <THead>
                <TR>
                  <TH>Linha original</TH>
                  <TH>Sugerido</TH>
                  <TH>Marca</TH>
                  <TH>Qtd</TH>
                  <TH>Preço</TH>
                  <TH>Conf.</TH>
                  <TH>{tCommon('actions')}</TH>
                </TR>
              </THead>
              <TBody>
                {current.normalized_rows.map((r: NormalizedRow) => (
                  <TR key={r.row_index}>
                    <TD className="text-xs text-muted-foreground max-w-xs truncate">{r.raw_text}</TD>
                    <TD className="font-medium">{r.suggested_name}</TD>
                    <TD>{r.brand ?? '—'}</TD>
                    <TD>{r.quantity} {r.unit}</TD>
                    <TD>{r.price?.toFixed(2)}</TD>
                    <TD>
                      <Badge variant={r.confidence > 0.7 ? 'success' : r.confidence > 0.4 ? 'warning' : 'destructive'}>
                        {(r.confidence * 100).toFixed(0)}%
                      </Badge>
                    </TD>
                    <TD>
                      <div className="flex gap-1">
                        <Button
                          size="sm" variant={decisions[r.row_index] === 'approve' ? 'default' : 'outline'}
                          onClick={() => setDecisions((d) => ({ ...d, [r.row_index]: 'approve' }))}
                        >
                          <Check className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          size="sm" variant={decisions[r.row_index] === 'ignore' ? 'destructive' : 'outline'}
                          onClick={() => setDecisions((d) => ({ ...d, [r.row_index]: 'ignore' }))}
                        >
                          <X className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </TD>
                  </TR>
                ))}
              </TBody>
            </Table>
            <div className="mt-3 flex justify-end">
              <Button onClick={onSubmitReview} disabled={busy || Object.keys(decisions).length === 0}>
                {t('approve')}
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader><CardTitle>Histórico</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR>
                <TH>Ficheiro</TH>
                <TH>{t('status')}</TH>
                <TH>{t('rows')}</TH>
                <TH>Aprovadas</TH>
                <TH>Data</TH>
              </TR>
            </THead>
            <TBody>
              {imports.map((i) => (
                <TR key={i.id}>
                  <TD className="font-medium">{i.original_filename}</TD>
                  <TD><Badge>{i.status}</Badge></TD>
                  <TD>{i.rows_total}</TD>
                  <TD>{i.rows_approved}</TD>
                  <TD className="text-xs text-muted-foreground">{new Date(i.created_at).toLocaleString()}</TD>
                </TR>
              ))}
              {!imports.length && (
                <TR><TD colSpan={5} className="text-center py-6 text-muted-foreground">{tCommon('noData')}</TD></TR>
              )}
            </TBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
