'use client';

import { useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, THead, TBody, TR, TH, TD } from '@/components/ui/table';
import { apiGet } from '@/lib/api';
import { formatCurrency, formatDate } from '@/lib/utils';
import type { Page, PurchaseOrder } from '@/types';

export default function OrdersPage() {
  const tCommon = useTranslations('common');
  const [data, setData] = useState<Page<PurchaseOrder> | null>(null);

  useEffect(() => {
    apiGet<Page<PurchaseOrder>>('/orders?size=50').then(setData).catch(() => null);
  }, []);

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Histórico de pedidos</h1>
        <p className="text-sm text-muted-foreground">{data?.total ?? 0} pedidos</p>
      </div>

      <Card>
        <CardHeader><CardTitle>Pedidos</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR>
                <TH>Código</TH>
                <TH>Fornecedor</TH>
                <TH>{tCommon('actions') /* status */}</TH>
                <TH>Total</TH>
                <TH>Itens</TH>
                <TH>Data</TH>
              </TR>
            </THead>
            <TBody>
              {data?.items.map((o) => (
                <TR key={o.id}>
                  <TD className="font-mono text-xs">{o.code}</TD>
                  <TD>{o.supplier_name}</TD>
                  <TD>
                    <Badge variant={
                      o.status === 'placed' ? 'success' :
                      o.status === 'cancelled' ? 'destructive' : 'secondary'
                    }>{o.status}</Badge>
                  </TD>
                  <TD>{formatCurrency(o.total_amount, o.currency)}</TD>
                  <TD>{o.items.length}</TD>
                  <TD className="text-xs text-muted-foreground">{formatDate(o.placed_at)}</TD>
                </TR>
              ))}
              {!data?.items.length && (
                <TR><TD colSpan={6} className="text-center py-8 text-muted-foreground">{tCommon('noData')}</TD></TR>
              )}
            </TBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
