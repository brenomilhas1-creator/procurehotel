'use client';

import { useEffect, useState } from 'react';
import { useTranslations } from 'next-intl';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, THead, TBody, TR, TH, TD } from '@/components/ui/table';
import { apiGet } from '@/lib/api';
import { formatDate } from '@/lib/utils';
import type { Page } from '@/types';

interface AdminUser { id: string; email: string; full_name: string; role: string; is_active: boolean; created_at: string; last_login_at: string | null; }

export default function UsersPage() {
  const tCommon = useTranslations('common');
  const [data, setData] = useState<Page<AdminUser> | null>(null);
  useEffect(() => {
    apiGet<Page<AdminUser>>('/users?size=50').then(setData).catch(() => null);
  }, []);
  return (
    <div className="space-y-6 animate-fade-in">
      <h1 className="text-2xl font-semibold tracking-tight">Utilizadores</h1>
      <Card>
        <CardHeader><CardTitle>Equipa</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <THead>
              <TR>
                <TH>Email</TH>
                <TH>Nome</TH>
                <TH>Perfil</TH>
                <TH>Estado</TH>
                <TH>Último login</TH>
              </TR>
            </THead>
            <TBody>
              {data?.items.map((u) => (
                <TR key={u.id}>
                  <TD>{u.email}</TD>
                  <TD>{u.full_name}</TD>
                  <TD><Badge variant={u.role === 'admin' ? 'default' : 'secondary'}>{u.role}</Badge></TD>
                  <TD><Badge variant={u.is_active ? 'success' : 'destructive'}>{u.is_active ? 'ativo' : 'inativo'}</Badge></TD>
                  <TD className="text-xs text-muted-foreground">{formatDate(u.last_login_at)}</TD>
                </TR>
              ))}
              {!data?.items.length && (
                <TR><TD colSpan={5} className="text-center py-8 text-muted-foreground">{tCommon('noData')}</TD></TR>
              )}
            </TBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
