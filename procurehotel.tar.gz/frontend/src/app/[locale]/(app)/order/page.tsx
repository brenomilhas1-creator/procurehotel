'use client';

import { useState } from 'react';
import { useTranslations } from 'next-intl';
import { Copy, Loader2, Sparkles, Send, ShoppingCart, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { apiPost } from '@/lib/api';
import { formatCurrency } from '@/lib/utils';
import type { FreeTextItem, OrderOptimizeResponse } from '@/types';

const EXAMPLE = `10 caixas coca cola
5kg queijo flamengo
20kg farinha nacional
3 un café grão 1kg
12 lt cerveja super bock 33cl
5 l leite UHT
2 sc sal 1kg`;

export default function OrderPage() {
  const t = useTranslations('order');
  const tCommon = useTranslations('common');
  const [text, setText] = useState(EXAMPLE);
  const [parsed, setParsed] = useState<FreeTextItem[] | null>(null);
  const [result, setResult] = useState<OrderOptimizeResponse | null>(null);
  const [loading, setLoading] = useState<null | 'parse' | 'optimize' | 'place'>(null);
  const [error, setError] = useState<string | null>(null);

  async function onParse() {
    setLoading('parse');
    setError(null);
    setResult(null);
    try {
      const res = await apiPost<{ items: FreeTextItem[] }>('/orders/parse', { text });
      setParsed(res.items);
    } catch (e: any) {
      setError(e?.message || 'Erro ao interpretar');
    } finally {
      setLoading(null);
    }
  }

  async function onOptimize() {
    if (!parsed) return;
    setLoading('optimize');
    setError(null);
    try {
      const res = await apiPost<OrderOptimizeResponse>('/orders/optimize', { items: parsed });
      setResult(res);
    } catch (e: any) {
      setError(e?.message || 'Erro a otimizar');
    } finally {
      setLoading(null);
    }
  }

  async function onMarkPlaced() {
    if (!result) return;
    setLoading('place');
    try {
      await apiPost('/orders/commit', { groups: result.groups, raw_input: text });
      setResult(null);
      setParsed(null);
      setText('');
    } catch (e: any) {
      setError(e?.message || 'Erro a gravar');
    } finally {
      setLoading(null);
    }
  }

  function copyGroup(supplierName: string, lines: string) {
    navigator.clipboard.writeText(lines);
  }

  return (
    <div className="space-y-6 animate-fade-in">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">{t('title')}</h1>
        <p className="text-sm text-muted-foreground">
          Escreva o pedido em linguagem natural. A IA interpreta, compara preços e divide por fornecedor.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-4 w-4 text-amber-500" /> Pedido
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <Textarea
            rows={6}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={t('placeholder')}
          />
          <div className="flex flex-wrap gap-2">
            <Button onClick={onParse} disabled={!text || loading !== null}>
              {loading === 'parse' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Sparkles className="h-4 w-4" />}
              {t('parse')}
            </Button>
            <Button onClick={onOptimize} disabled={!parsed || loading !== null} variant="secondary">
              {loading === 'optimize' ? <Loader2 className="h-4 w-4 animate-spin" /> : <ShoppingCart className="h-4 w-4" />}
              {t('optimize')}
            </Button>
            {result && (
              <Button onClick={onMarkPlaced} disabled={loading !== null}>
                {loading === 'place' ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                {t('markPlaced')}
              </Button>
            )}
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
        </CardContent>
      </Card>

      {/* Lista interpretada */}
      {parsed && parsed.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Interpretação da IA</CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm">
              {parsed.map((i, idx) => (
                <li key={idx} className="rounded-md border bg-muted/30 px-3 py-2">
                  <div className="font-medium">{i.quantity} {i.unit} · {i.product_name ?? i.raw_line}</div>
                  <div className="text-xs text-muted-foreground">{i.brand && <>Marca: {i.brand} · </>}{i.raw_line}</div>
                </li>
              ))}
            </ul>
          </CardContent>
        </Card>
      )}

      {/* Itens não matched */}
      {result && result.unmatchable.length > 0 && (
        <Card className="border-amber-500/40">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <AlertCircle className="h-4 w-4 text-amber-500" /> Itens sem correspondência ({result.unmatchable.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ul className="text-sm space-y-1">
              {result.unmatchable.map((u, i) => (
                <li key={i} className="text-muted-foreground">{u.raw_line}</li>
              ))}
            </ul>
            <p className="text-xs text-muted-foreground mt-2">
              Crie ou associe estes produtos no catálogo para que apareçam em próximos pedidos.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Grupos por fornecedor */}
      {result && result.groups.length > 0 && (
        <>
          <div className="flex items-center justify-between">
            <div>
              <div className="text-sm text-muted-foreground">Total estimado</div>
              <div className="text-3xl font-semibold">{formatCurrency(result.grand_total)}</div>
            </div>
            <Badge variant="success">{result.groups.length} fornecedores</Badge>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {result.groups.map((g) => {
              const lines = g.items.map((i) => `- ${i.quantity} ${i.unit} ${i.product_name}${i.is_substitution ? ' (substituição)' : ''}`).join('\n');
              return (
                <Card key={g.supplier_id}>
                  <CardHeader className="flex flex-row items-start justify-between space-y-0">
                    <div>
                      <CardTitle className="text-base">{g.supplier_name}</CardTitle>
                      <p className="text-xs text-muted-foreground">{g.item_count} {t('items')}</p>
                    </div>
                    <Button size="sm" variant="outline" onClick={() => copyGroup(g.supplier_name, lines)}>
                      <Copy className="h-3.5 w-3.5" /> {t('copy')}
                    </Button>
                  </CardHeader>
                  <CardContent>
                    <pre className="text-xs whitespace-pre-wrap bg-muted/40 rounded-md p-3 max-h-60 overflow-auto">
{lines}
                    </pre>
                    <div className="mt-2 flex justify-end text-sm font-medium">
                      {t('total')}: {formatCurrency(g.total)}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </>
      )}

      {!parsed && !result && !loading && (
        <p className="text-sm text-muted-foreground text-center py-12">
          Comece por escrever o seu pedido e clique em "{t('parse')}".
        </p>
      )}
    </div>
  );
}
