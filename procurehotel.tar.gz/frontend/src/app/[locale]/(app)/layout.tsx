import { DashboardLayout } from '@/components/shared/DashboardLayout';
import { AuthGuard } from '@/components/shared/Topbar';
import { unstable_setRequestLocale } from 'next-intl/server';

export default function AppLayout({
  children, params: { locale },
}: { children: React.ReactNode; params: { locale: string } }) {
  unstable_setRequestLocale(locale);
  return (
    <AuthGuard>
      <DashboardLayout>{children}</DashboardLayout>
    </AuthGuard>
  );
}
