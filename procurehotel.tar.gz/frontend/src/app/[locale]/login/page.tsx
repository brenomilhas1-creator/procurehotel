'use client';

import { useEffect, useState } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useTranslations, useLocale } from 'next-intl';
import { ChefHat, Loader2, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { useAuthStore } from '@/stores/auth';
import { getSupabase } from '@/lib/supabase';
import { apiGet } from '@/lib/api';

export default function LoginPage() {
  const t = useTranslations('auth');
  const tApp = useTranslations('app');
  const router = useRouter();
  const sp = useSearchParams();
  const locale = useLocale();
  const setSession = useAuthStore((s) => s.setSession);

  const [email, setEmail] = useState('admin@procurehotel.pt');
  const [password, setPassword] = useState('admin12345');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  // Se já houver sessão ativa, salta para o dashboard
  useEffect(() => {
    const sb = getSupabase();
    if (!sb) return;
    sb.auth.getSession().then(({ data }) => {
      if (data.session) {
        applySession(data.session.access_token, data.session.refresh_token);
      }
    });
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function applySession(access: string, refresh: string) {
    // gravar tokens imediatamente para a próxima chamada
    useAuthStore.setState({ accessToken: access, refreshToken: refresh });
    // buscar perfil local
    try {
      const me = await apiGet<any>('/auth/me');
      setSession({ accessToken: access, refreshToken: refresh, user: me });
    } catch {
      setSession({ accessToken: access, refreshToken: refresh });
    }
    const next = sp.get('next') || `/${locale}/dashboard`;
    router.push(next);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setInfo(null);
    const sb = getSupabase();
    if (!sb) {
      setError('Supabase não configurado. Verifica NEXT_PUBLIC_SUPABASE_URL / ANON_KEY.');
      setLoading(false);
      return;
    }
    const { data, error: sbErr } = await sb.auth.signInWithPassword({ email, password });
    if (sbErr || !data.session) {
      setError(sbErr?.message || t('invalid'));
      setLoading(false);
      return;
    }
    await applySession(data.session.access_token, data.session.refresh_token);
  }

  async function onMagicLink() {
    setLoading(true);
    setError(null);
    setInfo(null);
    const sb = getSupabase();
    if (!sb) {
      setError('Supabase não configurado.');
      setLoading(false);
      return;
    }
    const { error: sbErr } = await sb.auth.signInWithOtp({
      email,
      options: { emailRedirectTo: window.location.origin + `/${locale}/dashboard` },
    });
    setLoading(false);
    if (sbErr) setError(sbErr.message);
    else setInfo('Verifica o teu email para o link de acesso.');
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background via-background to-muted p-4">
      <Card className="w-full max-w-md animate-slide-up">
        <CardHeader className="text-center">
          <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <ChefHat className="h-6 w-6" />
          </div>
          <CardTitle className="text-2xl">{tApp('name')}</CardTitle>
          <CardDescription>{tApp('tagline')}</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <label className="text-sm font-medium">{t('email')}</label>
              <Input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
                     placeholder="admin@procurehotel.pt" required autoComplete="email" />
            </div>
            <div className="space-y-1.5">
              <label className="text-sm font-medium">{t('password')}</label>
              <Input type="password" value={password} onChange={(e) => setPassword(e.target.value)}
                     placeholder="••••••••" required autoComplete="current-password" />
            </div>
            {error && (
              <p className="text-sm text-destructive flex items-center gap-1.5">
                <AlertCircle className="h-4 w-4" /> {error}
              </p>
            )}
            {info && <p className="text-sm text-emerald-600 dark:text-emerald-400">{info}</p>}
            <div className="flex gap-2">
              <Button type="submit" className="flex-1" disabled={loading}>
                {loading && <Loader2 className="h-4 w-4 animate-spin" />}
                {t('submit')}
              </Button>
              <Button type="button" variant="outline" disabled={loading} onClick={onMagicLink}>
                Magic link
              </Button>
            </div>
            <p className="text-center text-xs text-muted-foreground">
              Autenticação via Supabase · primeiro admin deve ser criado no dashboard.
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
