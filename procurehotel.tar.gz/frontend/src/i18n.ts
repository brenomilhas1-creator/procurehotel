import { getRequestConfig } from 'next-intl/server';
import { notFound } from 'next/navigation';

export const locales = ['pt-PT', 'en'] as const;
export type AppLocale = (typeof locales)[number];
export const defaultLocale: AppLocale = 'pt-PT';

export default getRequestConfig(async ({ locale }) => {
  if (!locales.includes(locale as AppLocale)) notFound();
  return {
    messages: (await import(`./locales/${locale}.json`)).default,
  };
});
